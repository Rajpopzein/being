const PetTable = ()=>{
    return(
        <h1>table</h1>
    )
}

export default PetTable;