import React, { useEffect } from "react";
import { Formik } from "formik";
import {
  Avatar,
  Card,
  Badge,
  Grid,
  TextField,
  MenuItem,
  FormControl,
  FormLabel,
  Select
} from "@mui/material";
import CameraAltIcon from "@mui/icons-material/CameraAlt";
import "../pages/Adduser.css";
import { useState } from "react";
import "./style.css";
import * as Yup from "yup";
import CustomButton from "./Custombutton";
import { useSelector, useDispatch } from "react-redux";
import {
  getAllCountry,
  getState,
  getdistrict,
} from "../redux/slice/countryslice";
import Loaders from "./loader";

const SignupSchema = Yup.object().shape({
  username: Yup.string()
    .min(2, "Too Short!")
    .max(50, "Too Long!")
    .required("Required"),
  state: Yup.string().max(50).required("select a state"),
  emailId: Yup.string().email("Invalid email").required("Required"),
  country: Yup.string().required("Select a Country"),
  city: Yup.string(),
  //  .required('Select a city'),
  phoneNumber: Yup.string()
    .min(10, "Enter a valid Phone Number")
    .max(12, "T")
    .required("Enter Phone Number"),
});

// const countrydata = [];

const ValidationSchemaExample = () => {
  const [selectedFile, setSelectedFile] = useState(null);
  const [image, setImage] = useState("");
  const dispatch = useDispatch();
  const [loder, setLoder] = useState(true);
  const [country, setCountry] = useState([]);
  const [states, setState] = useState([]);
  const [district, setDistrict] = useState([]);
  const [selectedCountry, setSelectedCountry] = useState("");
  const [selectedState, setSelectedState] = useState("");
  const [selectedDistrict, setSelectedDistrict] = useState("");

  useEffect(() => {
    dispatch(getAllCountry());
  }, []);

  const dd = useSelector((state) => state.country);
  const statedata = useSelector((states) => states.state);
  const districtdata = useSelector((states) => states.district);

  useEffect(() => {
    setLoder(true);
    setCountry(dd?.userdata);
    setState(statedata.userdata);
    setDistrict(districtdata?.userdata);
    setTimeout(() => {
    setLoder(false);
    }, 5000);
  }, [dd, statedata, districtdata]);


  const mergeimgtodata = (values) => {
    const data = { ...values, image: selectedFile };
    return data;
  };

  const handleFileChange = (e, props) => {
    const file = e?.target?.files[0];
    setSelectedFile(file);
    // console.log('yyy',props)
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setImage(e.target.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handlecountyselect = (country) => {
    dispatch(getState(country));
    setSelectedCountry(country);
  };

  const handleStateSelect = (statesdatas, country) => {
    dispatch(getdistrict({countycode : country,statecode : statesdatas}));
    setSelectedState(statesdatas);
    console.log(districtdata, "dis")
  };

  return (
    <div>
      <Formik
        initialValues={{
          image: "",
          username: "",
          state: "",
          phoneNumber: "",
          city: "",
          emailId: "",
          address: "",
          country: "",
          pincode: "",
        }}
        validationSchema={SignupSchema}
        onSubmit={async (values, actions) => {
          setTimeout(async () => {
            const dd = mergeimgtodata(values);
            alert(JSON.stringify(dd, null, 2));
            console.log("alert", dd);
          }, 1000);
        }}
      >
        {(props) => (
          <form onSubmit={props.handleSubmit}>
            {/* {props.errors.name && <div id="feedback">{props.errors.name}</div>} */}
            <div style={{ marginLeft: "3rem" }}>
              <Badge
                overlap="circular"
                anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
                badgeContent={
                  <label htmlFor="fileInput">
                    <CameraAltIcon className="avatharcamera" />
                  </label>
                }
              >
                <Avatar
                  alt="image d"
                  src={image}
                  sx={{ width: 120, height: 120 }}
                />
                <input
                  type="file"
                  id="fileInput"
                  style={{ display: "none" }}
                  accept="image/*"
                  onChange={(e) => {
                    handleFileChange(e, props);
                  }}
                  name="image"
                />
              </Badge>
            </div>
            {loder ? (
              <div style={{ position: "absolute", left: "50%", top: "40%" }}>
                <Loaders />
              </div>
            ) : null}
            <div className="formcontrol" style={{ padding: "3rem 2rem" }}>
              <Grid
                container
                rowSpacing={3}
                columnSpacing={{ xs: 1, sm: 2, md: 3, lg: 6 }}
              >
                <Grid item xs={6}>
                  <div
                    className="formfields"
                    style={{ display: "flex", flexDirection: "column" }}
                  >
                    <label htmlFor="Username">User Name</label>
                    <TextField
                      id="Username"
                      className="formcontrolfield"
                      onChange={props.handleChange}
                      name="username"
                      value={props.values.username}
                      onBlur={props.handleBlur}
                      helperText={props.errors.username}
                    />
                    {/* {props?.errors?.username && props?.touched?.username ?(<div>{props?.errors.username}</div>):null} */}
                  </div>
                </Grid>
                <Grid item xs={6}>
                  <div
                    className="formfields"
                    style={{ display: "flex", flexDirection: "column" }}
                  >
                    <label htmlFor="phonenumber">Phone Number</label>
                    <TextField
                      id="phonenumber"
                      className="formcontrolfield"
                      onChange={props.handleChange}
                      name="phoneNumber"
                      onBlur={props.handleBlur}
                      helperText={props.errors.phoneNumber}
                    />
                  </div>
                </Grid>
                <Grid item xs={6}>
                  <div
                    className="formfields"
                    style={{ display: "flex", flexDirection: "column" }}
                  >
                    <label htmlFor="emailid">Email ID</label>
                    <TextField
                      id="emailid"
                      className="formcontrolfield"
                      onChange={props.handleChange}
                      name="emailId"
                      value={props.values.emailId}
                      onBlur={props.handleBlur}
                    />
                  </div>
                </Grid>
                <Grid item xs={6}>
                  <div
                    className="formfields"
                    style={{ display: "flex", flexDirection: "column" }}
                  >
                    <label htmlFor="address">Address</label>
                    <TextField
                      id="address"
                      className="formcontrolfield"
                      onChange={props.handleChange}
                      name="address"
                      value={props.values.address}
                      onBlur={props.handleBlur}
                    />
                  </div>
                </Grid>
                <Grid item xs={6}>
                  <div
                    className="formfields"
                    style={{ display: "flex", flexDirection: "column" }}
                  >
                    <label htmlFor="Country">Country</label>
                    <Select
                      id="Country"
                      select
                      defaultValue={props.values.country}
                      onChange={props.handleChange}
                      name="country"
                      value={props.values.country}
                      onBlur={props.handleBlur}
                      helperText={props.errors.country}
                    >
                      {country !== null &&
                        country?.map((option) => (
                          <MenuItem
                            key={option?.code}
                            value={option?.code}
                            onClick={() => handlecountyselect(option?.code)}
                          >
                            {option?.name}
                          </MenuItem>
                        ))}
                    </Select>
                  </div>
                </Grid>
                <Grid item xs={6}>
                  <div
                    className="formfields"
                    style={{ display: "flex", flexDirection: "column" }}
                  >
                    <label htmlFor="state">State</label>
                    <Select
                      id="state"
                      defaultValue={props.values.state}
                      helperText={props.errors.state}
                      onChange={props.handleChange}
                      name="state"
                      disabled={loder}
                    >
                      {
                        states?.map((option, index) => (
                          <MenuItem
                            key={index}
                            value={option.name}
                            onClick={() => handleStateSelect(option?.code, option?.country_code)}
                          >
                            {option?.name}
                          </MenuItem>
                        ))}
                    </Select>
                  </div>
                </Grid>

                <Grid item xs={6}>
                  <div
                    className="formfields"
                    style={{ display: "flex", flexDirection: "column" }}
                  >
                    <label htmlFor="city">City</label>
                    <TextField
                      id="city"
                      select
                      defaultValue={props.values.city}
                      onChange={props.handleChange}
                      name="city"
                      value={props.values.city}
                      onBlur={props.handleBlur}
                      helperText={props.errors.city}
                    >
                      {/* {countrydata.map((option) => (
                      <MenuItem key={option.value} value={option.value}>
                        {option.label}
                      </MenuItem>
                    ))} */}
                      {console.log("kk", district)}
                    </TextField>
                  </div>
                </Grid>

                <Grid item xs={6}>
                  <div
                    className="formfields"
                    style={{ display: "flex", flexDirection: "column" }}
                  >
                    <label htmlFor="Pincode">Pincode</label>
                    <TextField
                      id="Pincode"
                      className="formcontrolfield"
                      onChange={props.handleChange}
                      name="pincode"
                      value={props.values.pincode}
                      onBlur={props.handleBlur}
                    />
                  </div>
                </Grid>
              </Grid>
            </div>
            <div
              className="Fromiksubmit"
              style={{ display: "flex", marginLeft: "3rem", marginTop: "1rem" }}
            >
              <CustomButton
                name="Cancel"
                style={{
                  backgroundColor: "lightgray",
                  marginRight: "20px",
                  width: "14rem",
                  height: "3rem",
                }}
              />
              <CustomButton
                name="Submit"
                type="submit"
                style={{ width: "14rem", height: "3rem" }}
              />
            </div>
            {/* <button type="submit">Submit</button> */}
          </form>
        )}
      </Formik>
    </div>
  );
};

export default ValidationSchemaExample;
